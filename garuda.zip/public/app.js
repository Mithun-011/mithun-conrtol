const incidents = [
  { id: 'INC-042', title: 'Flash flood watch', sector: 'Lower estuary · Sector 04', severity: 'critical', status: 'Response active', age: '08 min ago', description: 'Water-level exercise alert at a low-lying crossing. A simulated response team is staged nearby.', kind: 'Flooding / water watch' },
  { id: 'INC-039', title: 'Slope movement watch', sector: 'West ridge · Sector 02', severity: 'high', status: 'Monitoring', age: '16 min ago', description: 'A simulated ground-movement sensor crossed the exercise threshold. Access teams are monitoring the scenario area.', kind: 'Infrastructure alert' },
  { id: 'INC-036', title: 'Medical evacuation', sector: 'South quay · Sector 09', severity: 'high', status: 'Response active', age: '23 min ago', description: 'A practice evacuation request has been logged for the South quay exercise sector.', kind: 'Medical evacuation' },
  { id: 'INC-031', title: 'Power corridor alert', sector: 'East depot · Sector 06', severity: 'moderate', status: 'Assessing', age: '31 min ago', description: 'Sample infrastructure alert affecting an exercise power corridor near the East depot.', kind: 'Infrastructure alert' },
  { id: 'INC-028', title: 'Shelter capacity check', sector: 'North campus · Sector 01', severity: 'moderate', status: 'Monitoring', age: '42 min ago', description: 'A demo shelter-capacity request is being reviewed by the scenario coordinator.', kind: 'Shelter request' },
  { id: 'INC-021', title: 'Road access disruption', sector: 'Canal road · Sector 03', severity: 'low', status: 'Resolved', age: '58 min ago', description: 'A simulated road-access issue has been marked clear for this exercise.', kind: 'Access disruption' },
  { id: 'INC-020', title: 'Shelter supply review', sector: 'North depot · Sector 05', severity: 'moderate', status: 'Monitoring', age: '1 hr 12 min ago', description: 'A sample shelter-supply review has been added to the exercise queue.', kind: 'Shelter request' },
  { id: 'INC-019', title: 'Access route inspection', sector: 'West bridge · Sector 07', severity: 'low', status: 'Assessing', age: '1 hr 27 min ago', description: 'A demo team is checking a route within the simulated response grid.', kind: 'Access disruption' },
  { id: 'INC-018', title: 'Medical kit resupply', sector: 'Central depot · Sector 05', severity: 'moderate', status: 'Queued', age: '1 hr 34 min ago', description: 'A synthetic request to move sample medical kits between exercise depots.', kind: 'Infrastructure alert' },
  { id: 'INC-017', title: 'Utility corridor inspection', sector: 'East verge · Sector 08', severity: 'moderate', status: 'Monitoring', age: '1 hr 46 min ago', description: 'A simulated utility-corridor inspection remains in the exercise watch list.', kind: 'Infrastructure alert' },
  { id: 'INC-016', title: 'Evacuation drill request', sector: 'South campus · Sector 10', severity: 'low', status: 'Resolved', age: '2 hr ago', description: 'A sample evacuation-drill request has been closed in the demo scenario.', kind: 'Shelter request' },
  { id: 'INC-015', title: 'Water point check', sector: 'Relief hub · Sector 12', severity: 'low', status: 'Assessing', age: '2 hr 15 min ago', description: 'A simulated water-point status check for the exercise relief hub.', kind: 'Flooding / water watch' }
];

const movementSignals = [
  { id: 'SIG-03', title: 'Repeated movement pattern', sector: 'Lower estuary · Sector 04', pattern: '2 of 3 synthetic sweeps', description: 'The exercise model records a repeated motion-like change. Water, debris, or other movement could create a similar cue; this does not confirm a person or a need for assistance.' },
  { id: 'SIG-02', title: 'Brief movement pattern', sector: 'North campus · Sector 01', pattern: '1 synthetic sweep', description: 'A single simulated pass contains a brief motion-like change. It is an uncertain lead for a trained person to review, not a confirmed human presence.' },
  { id: 'SIG-01', title: 'Low-amplitude pattern', sector: 'South quay · Sector 09', pattern: '1 synthetic sweep · low signal', description: 'A low-level change appears in one synthetic pass. Environmental motion may explain it; a field responder would decide whether a safe check is appropriate.' }
];

const severityNames = { critical: 'CRITICAL', high: 'HIGH', moderate: 'MODERATE', low: 'LOW' };
const state = { selectedId: 'INC-042', selectedSignalId: 'SIG-03', flaggedSignals: new Set(), filter: 'all', search: '', mapZoom: 1, toastTimer: null };
const incidentList = document.querySelector('#incident-list');
const incidentEmpty = document.querySelector('#incident-empty');
const dialog = document.querySelector('#incident-dialog');
const mapStage = document.querySelector('#map-stage');
const mapContent = document.querySelector('#map-content');
const movementList = document.querySelector('#movement-signal-list');

function svgIcon(symbol) {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
  use.setAttribute('href', `#${symbol}`);
  svg.append(use);
  return svg;
}

function mapOverlayLabel(overlay) {
  return ({ incidents: 'Incident markers', routes: 'Response routes', rainfall: 'Water-watch overlay', people: 'Potential people cues · synthetic only; human verification required' })[overlay];
}

function setMapOverlay(overlay, announce = true) {
  mapStage.dataset.overlay = overlay;
  document.querySelectorAll('.map-chip[data-overlay]').forEach((button) => {
    const active = button.dataset.overlay === overlay;
    button.classList.toggle('is-selected', active);
    button.setAttribute('aria-pressed', String(active));
  });
  document.querySelector('#map-route-toggle').setAttribute('aria-pressed', String(overlay === 'routes'));
  if (announce) showToast(`${mapOverlayLabel(overlay)} shown on the schematic demo map.`);
}

function renderSignalDetail() {
  const selected = movementSignals.find((signal) => signal.id === state.selectedSignalId);
  if (!selected) return;
  const flagged = state.flaggedSignals.has(selected.id);
  document.querySelector('#signal-detail-id').textContent = selected.id;
  document.querySelector('#signal-detail-status').textContent = flagged ? 'REVIEW FLAGGED' : 'UNVERIFIED';
  document.querySelector('#signal-detail-title').textContent = selected.title;
  document.querySelector('#signal-detail-sector').textContent = selected.sector;
  document.querySelector('#signal-detail-copy').textContent = selected.description;
  document.querySelector('#signal-detail-pattern').textContent = selected.pattern;
  const reviewButton = document.querySelector('#movement-review-toggle');
  reviewButton.setAttribute('aria-pressed', String(flagged));
  reviewButton.setAttribute('aria-label', flagged ? `Remove local review flag for ${selected.id}` : `Flag ${selected.id} for human review in this demo`);
  reviewButton.querySelector('span').textContent = flagged ? 'Remove local review flag' : 'Flag for human review';
  document.querySelector('#movement-review-note').textContent = flagged ? 'Demo flag saved in this browser only · no field team is contacted.' : 'Local demo only · no field team is contacted.';
}

function renderMovementSignals() {
  const focusedId = movementList.contains(document.activeElement) ? document.activeElement.dataset.signal : null;
  movementList.replaceChildren();
  movementSignals.forEach((signal) => {
    const row = document.createElement('button');
    row.type = 'button';
    row.className = `movement-row${signal.id === state.selectedSignalId ? ' is-selected' : ''}`;
    row.dataset.signal = signal.id;
    row.setAttribute('aria-pressed', String(signal.id === state.selectedSignalId));
    row.setAttribute('aria-label', `${signal.title}, ${signal.sector}; synthetic and unverified${state.flaggedSignals.has(signal.id) ? ', local human-review flag recorded' : ''}`);
    const icon = document.createElement('span');
    icon.className = 'movement-row-icon';
    icon.append(svgIcon('icon-person'));
    const copy = document.createElement('span');
    copy.className = 'movement-row-copy';
    const title = document.createElement('strong');
    title.textContent = signal.title;
    const sector = document.createElement('small');
    sector.textContent = `${signal.id} · ${signal.sector}`;
    copy.append(title, sector);
    const status = document.createElement('span');
    status.className = 'movement-row-status';
    status.textContent = state.flaggedSignals.has(signal.id) ? 'FLAGGED' : 'UNVERIFIED';
    row.append(icon, copy, status);
    row.addEventListener('click', () => selectMovementSignal(signal.id));
    movementList.append(row);
  });
  if (focusedId) movementList.querySelector(`[data-signal="${focusedId}"]`)?.focus({ preventScroll: true });
  document.querySelector('#movement-cue-count').textContent = String(movementSignals.length).padStart(2, '0');
  document.querySelector('#movement-summary-count').textContent = String(movementSignals.length).padStart(2, '0');
  document.querySelectorAll('.movement-marker').forEach((marker) => {
    const active = marker.dataset.signal === state.selectedSignalId;
    marker.classList.toggle('is-selected', active);
    marker.setAttribute('aria-pressed', String(active));
  });
  renderSignalDetail();
}

function selectMovementSignal(id) {
  const selected = movementSignals.find((signal) => signal.id === id);
  if (!selected) return;
  state.selectedSignalId = id;
  setMapOverlay('people', false);
  renderMovementSignals();
  document.querySelector('#movement-announcement').textContent = `Selected synthetic movement cue ${selected.id} at ${selected.sector}. Unverified; human review is required.`;
}

function statusClass(status) {
  if (status === 'Monitoring' || status === 'Assessing') return 'status-monitor';
  if (status === 'Queued') return 'status-queued';
  if (status === 'Resolved') return 'status-resolved';
  return '';
}

function renderIncidents() {
  const focusedId = incidentList.contains(document.activeElement) ? document.activeElement.dataset.incident : null;
  const term = state.search.trim().toLowerCase();
  const visible = incidents.filter((incident) => {
    const matchesSeverity = state.filter === 'all' || incident.severity === state.filter;
    const matchesSearch = !term || `${incident.id} ${incident.title} ${incident.sector} ${incident.status}`.toLowerCase().includes(term);
    return matchesSeverity && matchesSearch;
  });
  incidentList.replaceChildren();
  visible.forEach((incident) => {
    const row = document.createElement('button');
    row.type = 'button';
    row.className = `incident-row${incident.id === state.selectedId ? ' is-selected' : ''}`;
    row.dataset.incident = incident.id;
    row.setAttribute('aria-pressed', String(incident.id === state.selectedId));
    row.setAttribute('aria-label', `${severityNames[incident.severity]}: ${incident.title}, ${incident.sector}, ${incident.status}`);

    const severityBar = document.createElement('span');
    severityBar.className = `incident-severity-bar ${incident.severity}`;
    severityBar.setAttribute('aria-hidden', 'true');
    const main = document.createElement('span');
    main.className = 'incident-row-main';
    const title = document.createElement('span');
    title.className = 'incident-row-title';
    const titleText = document.createElement('span');
    titleText.textContent = incident.title;
    const id = document.createElement('span');
    id.className = 'incident-id';
    id.textContent = incident.id;
    title.append(titleText, id);
    const location = document.createElement('span');
    location.className = 'incident-row-location';
    location.textContent = incident.sector;
    main.append(title, location);
    const trailing = document.createElement('span');
    trailing.className = 'incident-row-trailing';
    const status = document.createElement('span');
    status.className = `incident-status ${statusClass(incident.status)}`;
    const statusDot = document.createElement('i');
    statusDot.setAttribute('aria-hidden', 'true');
    const statusLabel = document.createElement('span');
    statusLabel.textContent = incident.status;
    status.append(statusDot, statusLabel);
    const age = document.createElement('span');
    age.className = 'incident-age';
    age.textContent = incident.age;
    trailing.append(status, age);
    row.append(severityBar, main, trailing);
    row.addEventListener('click', () => selectIncident(incident.id));
    incidentList.append(row);
  });
  if (focusedId) {
    incidentList.querySelector(`[data-incident="${focusedId}"]`)?.focus({ preventScroll: true });
  }
  incidentEmpty.hidden = visible.length > 0;
  document.querySelector('#queue-count').textContent = String(incidents.length).padStart(2, '0');
  document.querySelector('#filter-count-all').textContent = String(incidents.length);
  document.querySelector('#open-count').textContent = String(incidents.length).padStart(2, '0');
  const priorities = incidents.filter((incident) => incident.severity === 'critical' || incident.severity === 'high').length;
  document.querySelector('#priority-count').textContent = String(priorities).padStart(2, '0');
  document.querySelector('.nav-count').textContent = String(incidents.length);
}

function renderSelected() {
  const selected = incidents.find((incident) => incident.id === state.selectedId);
  if (!selected) return;
  const severity = document.querySelector('#selected-severity');
  severity.textContent = severityNames[selected.severity];
  severity.className = `severity-label severity-${selected.severity}-text`;
  document.querySelector('#selected-id').textContent = selected.id;
  document.querySelector('#selected-title').textContent = selected.title;
  document.querySelector('#selected-sector').textContent = selected.sector;
  document.querySelector('#selected-description').textContent = selected.description;
  document.querySelector('#selected-status').textContent = selected.status;
  document.querySelector('#selected-age').textContent = selected.age;
  document.querySelector('#selection-announcement').textContent = `Selected ${severityNames[selected.severity]} report ${selected.id}: ${selected.title}, ${selected.sector}, ${selected.status}.`;
  document.querySelectorAll('.map-marker').forEach((marker) => {
    const active = marker.dataset.marker === selected.id;
    marker.classList.toggle('is-selected', active);
    marker.setAttribute('aria-pressed', String(active));
  });
}

function selectIncident(id) {
  if (!incidents.some((incident) => incident.id === id)) return;
  state.selectedId = id;
  renderIncidents();
  renderSelected();
  if (!document.querySelector(`.map-marker[data-marker="${id}"]`)) {
    showToast(`${id} is not geocoded on this schematic demo map.`);
  }
}

function showToast(message) {
  const toast = document.querySelector('#toast');
  document.querySelector('#toast-message').textContent = message;
  toast.classList.add('is-visible');
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => toast.classList.remove('is-visible'), 3400);
}

function setZoom(nextZoom) {
  state.mapZoom = Math.min(1.32, Math.max(.88, nextZoom));
  mapContent.style.setProperty('--map-zoom', state.mapZoom.toFixed(2));
}

function setActiveNav() {
  const hash = window.location.hash.replace('#', '') || 'overview';
  document.querySelectorAll('.nav-link').forEach((link) => {
    link.classList.toggle('is-active', link.dataset.nav === hash);
  });
}

document.querySelector('#incident-search').addEventListener('input', (event) => {
  state.search = event.target.value;
  renderIncidents();
});

document.querySelectorAll('[data-filter]').forEach((button) => {
  button.addEventListener('click', () => {
    state.filter = button.dataset.filter;
    document.querySelectorAll('[data-filter]').forEach((item) => {
      const active = item === button;
      item.classList.toggle('is-active', active);
      item.setAttribute('aria-pressed', String(active));
    });
    renderIncidents();
  });
});

document.querySelector('#view-all-button').addEventListener('click', () => {
  state.filter = 'all';
  state.search = '';
  document.querySelector('#incident-search').value = '';
  document.querySelectorAll('[data-filter]').forEach((button) => {
    const active = button.dataset.filter === 'all';
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  });
  renderIncidents();
  showToast(`Showing all ${incidents.length} sample reports.`);
});

document.querySelectorAll('[data-marker]').forEach((marker) => {
  marker.addEventListener('click', () => selectIncident(marker.dataset.marker));
});
document.querySelectorAll('.movement-marker').forEach((marker) => {
  marker.addEventListener('click', () => selectMovementSignal(marker.dataset.signal));
});

document.querySelectorAll('.map-chip[data-overlay]').forEach((button) => {
  button.addEventListener('click', () => setMapOverlay(button.dataset.overlay));
});

document.querySelector('#map-route-toggle').addEventListener('click', () => {
  setMapOverlay(mapStage.dataset.overlay === 'routes' ? 'incidents' : 'routes');
});
document.querySelector('#movement-review-toggle').addEventListener('click', () => {
  const id = state.selectedSignalId;
  const isFlagged = state.flaggedSignals.has(id);
  if (isFlagged) state.flaggedSignals.delete(id);
  else state.flaggedSignals.add(id);
  renderMovementSignals();
  document.querySelector('#movement-announcement').textContent = isFlagged ? `Local human-review flag removed for ${id}. No field team was contacted.` : `${id} flagged for human review in this local demo. No field team was contacted.`;
  showToast(isFlagged ? `Local review flag removed for ${id}. No field team was contacted.` : `${id} flagged locally for human review. No field team was contacted.`);
});
document.querySelector('#zoom-in').addEventListener('click', () => setZoom(state.mapZoom + .1));
document.querySelector('#zoom-out').addEventListener('click', () => setZoom(state.mapZoom - .1));
document.querySelector('#zoom-reset').addEventListener('click', () => setZoom(1));

document.querySelector('#new-incident-button').addEventListener('click', () => {
  document.querySelector('#incident-form').reset();
  if (typeof dialog.showModal === 'function') dialog.showModal();
  else showToast('The incident form is unavailable in this browser.');
});
document.querySelectorAll('[data-close-dialog]').forEach((button) => button.addEventListener('click', () => dialog.close()));
dialog.addEventListener('click', (event) => {
  if (event.target === dialog) dialog.close();
});

document.querySelector('#incident-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const sector = document.querySelector('#incident-sector').value.trim();
  if (!sector) return;
  const nextNumber = Math.max(...incidents.map((incident) => Number(incident.id.slice(-3)))) + 1;
  const id = `INC-${String(nextNumber).padStart(3, '0')}`;
  const kind = document.querySelector('#incident-kind').value;
  const priority = document.querySelector('#incident-priority').value;
  const note = document.querySelector('#incident-note').value.trim();
  incidents.unshift({
    id,
    title: kind.replace(' / water watch', ' watch'),
    sector,
    severity: priority,
    status: 'Queued',
    age: 'Just now',
    description: note || `${kind} was added as a temporary sample report in this browser session. No location verification or dispatch is performed.`,
    kind
  });
  state.filter = 'all';
  state.search = '';
  document.querySelector('#incident-search').value = '';
  document.querySelectorAll('[data-filter]').forEach((button) => {
    const active = button.dataset.filter === 'all';
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  });
  state.selectedId = id;
  renderIncidents();
  renderSelected();
  dialog.close();
  showToast(`${id} added to the local demo queue. No map pin was geocoded.`);
});

document.querySelector('#refresh-button').addEventListener('click', () => {
  renderIncidents();
  renderMovementSignals();
  const time = new Intl.DateTimeFormat('en-IN', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Kolkata' }).format(new Date());
  showToast(`Demo incidents and movement cues refreshed at ${time} IST. No live sensor feed was queried.`);
});

document.querySelectorAll('[data-toast]').forEach((button) => {
  button.addEventListener('click', () => showToast(button.dataset.toast));
});

document.querySelectorAll('.nav-link').forEach((link) => link.addEventListener('click', () => {
  setActiveNav();
}));
window.addEventListener('hashchange', setActiveNav);

document.addEventListener('keydown', (event) => {
  if (event.key === '/' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName)) {
    event.preventDefault();
    document.querySelector('#incident-search').focus();
  }
  if (event.key === 'Escape' && dialog.open) dialog.close();
});

function updateClock() {
  document.querySelector('#live-clock').textContent = `${new Intl.DateTimeFormat('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'Asia/Kolkata', hour12: false }).format(new Date())} IST`;
}

setMapOverlay('incidents', false);
renderMovementSignals();
renderIncidents();
renderSelected();
setActiveNav();
updateClock();
setInterval(updateClock, 1000);
